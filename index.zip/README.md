
# 🧩 Jigsaw Brick Breaker

Welcome to **Jigsaw Brick Breaker** — a horror-themed arcade game built with HTML5 and JavaScript, styled like SAW.

## 🎮 Features
- Power-ups (expand, shrink, multiball, slow)
- Coin collection and upgrade shop
- Persistent progress via localStorage
- Achievements and enemies
- Custom paddle skins and sound effects

## 🛠 How to Run
1. Upload everything to a GitHub repo
2. Make sure `index.html` is in the root
3. Enable GitHub Pages (Settings > Pages > Source: main branch, root)
4. Visit: `https://<your-username>.github.io/<repo-name>/`

---

Built with 💀 by Corbyn Davidson
